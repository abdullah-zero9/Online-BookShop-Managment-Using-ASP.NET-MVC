﻿namespace Ans_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ScriptA : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Books",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        BookName = c.String(),
                        Price = c.Decimal(nullable: false, precision: 18, scale: 2),
                        PublishDate = c.DateTime(nullable: false, storeType: "date"),
                        PicturePath = c.String(),
                        Avialable = c.Boolean(nullable: false),
                        CId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Categories", t => t.CId, cascadeDelete: true)
                .Index(t => t.CId);
            
            CreateTable(
                "dbo.Categories",
                c => new
                    {
                        CId = c.Int(nullable: false, identity: true),
                        CName = c.String(),
                    })
                .PrimaryKey(t => t.CId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Books", "CId", "dbo.Categories");
            DropIndex("dbo.Books", new[] { "CId" });
            DropTable("dbo.Categories");
            DropTable("dbo.Books");
        }
    }
}
