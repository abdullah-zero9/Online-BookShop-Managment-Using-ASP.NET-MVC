﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using System.Data.Entity;

namespace Ans_1.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string BookName { get; set; }
        public decimal Price { get; set; }
        [Column(TypeName = "date"), Display(Name = "Publish Date"), DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public System.DateTime PublishDate { get; set; }
        public string PicturePath { get; set; }
        public bool Avialable { get; set; }
        public int CId { get; set; }

        public virtual Category Category { get; set; }
    }
    public class Category
    {
        public Category()
        {
            this.Books = new HashSet<Book>();
        }
        [Key]
        public int CId { get; set; }
        public string CName { get; set; }
        public virtual ICollection<Book> Books { get; set; }
    }
    public class R53_MVCEntities : DbContext
    {
        public DbSet<Book> Books { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}